<?php
/*
 * Simple Child Theme genearted by Ultimatum Framework
*/
$theme = array(		
		'theme_name' => 'CINEREAL',
		'theme_slug' =>'cinereal',
);
require_once( get_template_directory() . '/wonderfoundry/wonderworks.php' );

// remove wp version meta tag and from rss feed
function at_remove_wp_ver_meta_rss() {
    return '';
}
add_filter( 'the_generator', 'at_remove_wp_ver_meta_rss' );

// remove wp version param from any enqueued scripts
function at_remove_wp_ver_css_js( $src ) {
    if ( strpos( $src, 'ver=' ) )
        $src = remove_query_arg( 'ver', $src );
    return $src;
}
add_filter( 'style_loader_src', 'at_remove_wp_ver_css_js', 9999 );
add_filter( 'script_loader_src', 'at_remove_wp_ver_css_js', 9999 );

function moveon()
{
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' ) ;
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' ); 
}
add_action( 'after_setup_theme', 'moveon' );

add_action('init', 'myoverride', 100);
function myoverride() {
    remove_action('wp_head', array(visual_composer(), 'addMetaData'));
}

// REMOVE WP EMOJI
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');   
